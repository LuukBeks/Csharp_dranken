﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Dranken2
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        public Window1()
        {
            InitializeComponent();
            dgDranken3.ItemsSource = db.Drankens.ToList();
        }

        private void dgDranken3_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Dranken drankenrow = (Dranken)dgDranken3.SelectedItem;
            int ID = drankenrow.ID;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            
            {
                DataClasses1DataContext DR = new DataClasses1DataContext();
                Dranken drankenrow = dgDranken3.SelectedItem as Dranken;
                var drankje = (from Dranken in DR.Drankens
                               where Dranken.ID == drankenrow.ID
                               select Dranken).Single();

                DR.Drankens.DeleteOnSubmit(drankje);
                DR.SubmitChanges();
                dgDranken3.ItemsSource = db.Drankens.ToList();
            }
        }

        private void Searchbtn_Click(object sender, RoutedEventArgs e)
        {
            string did = Searchtxt.Text;
            var lijst = db.Drankens.Where(p => Convert.ToString(p.ID).Contains(did));
            var list = db.Drankens.Where(p => Convert.ToString(p.soort).Contains(did));
            dgDranken3.ItemsSource = lijst;
            dgDranken3.ItemsSource = list;
        }

        private void page1txt_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }
    }
}
